<!DOCTYPE html>
<html>
<head>
	<title>Search</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
</head>
<body>
<div class="container-fluid">
	<input type="text" name="search" class="form-control" placeholder="Search" required="" id="search" autocomplete="off">
	<div class="searchbox">
		
	</div>
</div>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
	$("#search").keyup(function(){
		$.ajax({
			url:'search.php',
			type:'post',
			dataType:'html',
			data:{search:$("#search").val()},
			success:function(data){
				$(".searchbox").html(data)
			},
			error:function(data){
				console.log('Error!'+data)
			}
		})
	})
</script>
<style type="text/css">
	.searchbox{
		text-align: center;
		text-transform: capitalize;
	}
</style>
</body>
</html>