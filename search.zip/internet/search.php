<?php
require 'config.php';
$data=$_POST;
if($data['search']){
	$search = R::Find('search','name LIKE :name',array(':name'=>'%'.$data['search'].'%'));//search
	//if($search){
	foreach ($search as $key) {
	echo '<br><h1>'.$key['name'].'</h1>';
	}
}else{
	echo '<h1>No Results!</h1>';
}




?>