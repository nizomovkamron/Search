<?php
require 'rb.php';
R::setup('mysql:host=localhost;dbname=search','root','');//база данных

?>